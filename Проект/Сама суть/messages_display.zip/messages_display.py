# import os
# os.makedirs('kfsdjkkfsd')

def start_message_display(self, folder):
    pass
	
